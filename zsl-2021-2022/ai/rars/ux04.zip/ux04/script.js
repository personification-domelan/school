var handler = document.getElementById('handler')

handler.style = "color: yellow; font-size: 20px; font-family: 'Courier New', Courier, monospace; width: 100px; height: 100px; border-color: blue; border-style: dashed; border-width:10px; background-color: magenta"