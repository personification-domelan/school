CREATE DATABASE if NOT EXISTS `Pliki`;
USE `Pliki`;
CREATE TABLE `source1` (
	filename varchar(20),
	extension char(3),
	lenght int,
	date date
	);
CREATE TABLE `source2` (
	filename varchar(20),
	extension char(3),
	lenght int,
	date date
	);
CREATE TABLE `pendrive` (
	filename varchar(20),
	extension char(3),
	lenght int,
	date date
	);
CREATE TABLE `source4` (
	filename varchar(20),
	extension char(3),
	lenght int,
	date date
	);