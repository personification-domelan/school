INSERT INTO daneosobowe VALUES (81011220232,'Danio','Malabarski','1982-10-11','m',NULL);
INSERT INTO kontaserwisu(Login,Haslo,Data_utworzenia) VALUES ('DanioM','SSL@#1',NOW());
